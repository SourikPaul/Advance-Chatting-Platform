package com.fireball.backend;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class ChatWebSocketHandler extends TextWebSocketHandler {

    private static final Map<String, WebSocketSession> userSessions = new ConcurrentHashMap<>();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        Map<String, String> data = objectMapper.readValue(message.getPayload(), Map.class);
        String type = data.get("type");

        if ("register".equals(type)) {
            String username = data.get("username");
            if (username != null && !username.isBlank()) {
                userSessions.put(username, session);
            }
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        userSessions.entrySet().removeIf(entry -> entry.getValue().getId().equals(session.getId()));
    }

    public void sendMessageToUser(String username, String payload) throws Exception {
        WebSocketSession session = userSessions.get(username);
        if (session != null && session.isOpen()) {
            session.sendMessage(new TextMessage(payload));
        }
    }
}
