package com.fireball.backend;

import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/friends")
@CrossOrigin
public class FriendRequestController {

    private final FriendRequestRepository friendRequestRepository;
    private final UserRepository userRepository;

    public FriendRequestController(FriendRequestRepository friendRequestRepository, UserRepository userRepository) {
        this.friendRequestRepository = friendRequestRepository;
        this.userRepository = userRepository;
    }

    @PostMapping("/request")
    public Map<String, Object> sendFriendRequest(@RequestBody Map<String, String> body) {
        Map<String, Object> response = new HashMap<>();

        String sender = body.get("senderUsername");
        String receiver = body.get("receiverUsername");

        if (sender == null || receiver == null || sender.isBlank() || receiver.isBlank()) {
            response.put("success", false);
            response.put("message", "Both usernames are required");
            return response;
        }

        if (sender.equals(receiver)) {
            response.put("success", false);
            response.put("message", "You cannot add yourself");
            return response;
        }

        if (userRepository.findByUsername(receiver).isEmpty()) {
            response.put("success", false);
            response.put("message", "User does not exist");
            return response;
        }

        Optional<FriendRequest> existing =
                friendRequestRepository.findBySenderUsernameAndReceiverUsername(sender, receiver);

        if (existing.isPresent()) {
            response.put("success", false);
            response.put("message", "Friend request already sent");
            return response;
        }

        FriendRequest request = new FriendRequest(sender, receiver, "PENDING");
        friendRequestRepository.save(request);

        response.put("success", true);
        response.put("message", "Friend request sent");
        return response;
    }

    @GetMapping("/requests/{username}")
    public List<FriendRequest> getPendingRequests(@PathVariable String username) {
        return friendRequestRepository.findByReceiverUsernameAndStatus(username, "PENDING");
    }

    @PostMapping("/accept/{id}")
    public Map<String, Object> acceptFriendRequest(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();

        Optional<FriendRequest> requestOptional = friendRequestRepository.findById(id);

        if (requestOptional.isEmpty()) {
            response.put("success", false);
            response.put("message", "Friend request not found");
            return response;
        }

        FriendRequest request = requestOptional.get();
        request.setStatus("ACCEPTED");
        friendRequestRepository.save(request);

        response.put("success", true);
        response.put("message", "Friend request accepted");
        return response;
    }

    @GetMapping("/list/{username}")
public List<String> getFriendsList(@PathVariable String username) {
    List<FriendRequest> sentAccepted = friendRequestRepository.findBySenderUsernameAndStatus(username, "ACCEPTED");
    List<FriendRequest> receivedAccepted = friendRequestRepository.findByReceiverUsernameAndStatus(username, "ACCEPTED");

    List<String> friends = new java.util.ArrayList<>();

    for (FriendRequest request : sentAccepted) {
        friends.add(request.getReceiverUsername());
    }

    for (FriendRequest request : receivedAccepted) {
        friends.add(request.getSenderUsername());
    }

    return friends;
}

}
