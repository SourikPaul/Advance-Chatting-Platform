package com.fireball.backend;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/messages")
@CrossOrigin
public class MessageController {

    private final MessageRepository messageRepository;
    private final ChatWebSocketHandler chatWebSocketHandler;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public MessageController(MessageRepository messageRepository, ChatWebSocketHandler chatWebSocketHandler) {
        this.messageRepository = messageRepository;
        this.chatWebSocketHandler = chatWebSocketHandler;
    }

    @GetMapping
    public List<Message> getConversation(
            @RequestParam String user1,
            @RequestParam String user2
    ) {
        return messageRepository
                .findBySenderUsernameAndReceiverUsernameOrSenderUsernameAndReceiverUsernameOrderByTimestampAsc(
                        user1, user2, user2, user1
                );
    }

    @PostMapping
    public Message sendMessage(@RequestBody Message message) {
        message.setTimestamp(LocalDateTime.now());
        Message savedMessage = messageRepository.save(message);

        try {
            String payload = objectMapper.writeValueAsString(savedMessage);
            chatWebSocketHandler.sendMessageToUser(savedMessage.getReceiverUsername(), payload);
            chatWebSocketHandler.sendMessageToUser(savedMessage.getSenderUsername(), payload);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return savedMessage;
    }
}
