package com.fireball.backend;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FriendRequestRepository extends JpaRepository<FriendRequest, Long> {
    List<FriendRequest> findByReceiverUsernameAndStatus(String receiverUsername, String status);

    List<FriendRequest> findBySenderUsernameAndStatus(String senderUsername, String status);

    Optional<FriendRequest> findBySenderUsernameAndReceiverUsername(String senderUsername, String receiverUsername);
}
