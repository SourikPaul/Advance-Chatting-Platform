const authScreen = document.getElementById("authScreen");
const chatScreen = document.getElementById("chatScreen");

const authUsername = document.getElementById("authUsername");
const authPassword = document.getElementById("authPassword");
const signupBtn = document.getElementById("signupBtn");
const loginBtn = document.getElementById("loginBtn");
const authMessage = document.getElementById("authMessage");

const currentUser = document.getElementById("currentUser");
const chatTitle = document.getElementById("chatTitle");
const chatSubtitle = document.getElementById("chatSubtitle");
const messagesContainer = document.getElementById("messages");
const messageForm = document.getElementById("messageForm");
const contentInput = document.getElementById("content");
const sendBtn = document.getElementById("sendBtn");

const friendUsernameInput = document.getElementById("friendUsername");
const sendFriendRequestBtn = document.getElementById("sendFriendRequestBtn");
const friendMessage = document.getElementById("friendMessage");
const friendRequestsContainer = document.getElementById("friendRequests");
const friendsListContainer = document.getElementById("friendsList");

const settingsBtn = document.getElementById("settingsBtn");
const logoutBtn = document.getElementById("logoutBtn");
const logoutModal = document.getElementById("logoutModal");
const cancelLogoutBtn = document.getElementById("cancelLogoutBtn");
const confirmLogoutBtn = document.getElementById("confirmLogoutBtn");

let loggedInUser = null;
let selectedFriend = null;
let socket = null;

function formatMessageTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();

    const isToday =
        date.getDate() === now.getDate() &&
        date.getMonth() === now.getMonth() &&
        date.getFullYear() === now.getFullYear();

    if (isToday) {
        return date.toLocaleTimeString([], {
            hour: "numeric",
            minute: "2-digit"
        });
    }

    return date.toLocaleString([], {
        day: "numeric",
        month: "short",
        hour: "numeric",
        minute: "2-digit"
    });
}

function shouldGroupWithPrevious(previousMessage, currentMessage) {
    if (!previousMessage) return false;
    if (previousMessage.senderUsername !== currentMessage.senderUsername) return false;

    const previousTime = new Date(previousMessage.timestamp).getTime();
    const currentTime = new Date(currentMessage.timestamp).getTime();
    const diffInMinutes = (currentTime - previousTime) / 1000 / 60;

    return diffInMinutes < 1;
}

function renderMessages(messages) {
    messagesContainer.innerHTML = "";

    if (!messages || messages.length === 0) {
        messagesContainer.innerHTML = `<p class="empty-state">No messages yet. Start the conversation.</p>`;
        return;
    }

    let currentGroupAnchor = null;
    let currentGroupMessages = [];

    function flushGroup() {
        if (!currentGroupAnchor || currentGroupMessages.length === 0) return;

        const groupElement = document.createElement("div");
        groupElement.classList.add("message-group");

        const metaElement = document.createElement("div");
        metaElement.classList.add("message-meta");
        metaElement.innerHTML = `
            <span class="message-sender">${currentGroupAnchor.senderUsername}</span>
            <span class="message-time">${formatMessageTime(currentGroupAnchor.timestamp)}</span>
        `;

        const bubbleElement = document.createElement("div");
        bubbleElement.classList.add("message-bubble");

        currentGroupMessages.forEach((msg) => {
            const lineElement = document.createElement("div");
            lineElement.classList.add("message-line");
            lineElement.textContent = msg.content;
            bubbleElement.appendChild(lineElement);
        });

        groupElement.appendChild(metaElement);
        groupElement.appendChild(bubbleElement);
        messagesContainer.appendChild(groupElement);
    }

    for (let i = 0; i < messages.length; i++) {
        const message = messages[i];
        const previousMessage = i > 0 ? messages[i - 1] : null;

        if (!shouldGroupWithPrevious(previousMessage, message)) {
            flushGroup();
            currentGroupAnchor = message;
            currentGroupMessages = [message];
        } else {
            currentGroupMessages.push(message);
        }
    }

    flushGroup();
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

async function loadMessages() {
    if (!loggedInUser || !selectedFriend) {
        messagesContainer.innerHTML = `<p class="empty-state">Select a friend to view your conversation.</p>`;
        return;
    }

    const response = await fetch(
        `/messages?user1=${encodeURIComponent(loggedInUser)}&user2=${encodeURIComponent(selectedFriend)}`
    );
    const messages = await response.json();
    renderMessages(messages);
}

async function loadFriendRequests() {
    if (!loggedInUser) return;

    const response = await fetch(`/friends/requests/${encodeURIComponent(loggedInUser)}`);
    const requests = await response.json();

    friendRequestsContainer.innerHTML = "";

    if (requests.length === 0) {
        friendRequestsContainer.innerHTML = `<p class="empty-state">No pending requests</p>`;
        return;
    }

    requests.forEach((request) => {
        const requestElement = document.createElement("div");
        requestElement.classList.add("friend-request");
        requestElement.innerHTML = `
            <div><strong>${request.senderUsername}</strong> sent you a request</div>
            <button type="button" onclick="acceptFriendRequest(${request.id})">Accept</button>
        `;
        friendRequestsContainer.appendChild(requestElement);
    });
}

async function loadFriends() {
    if (!loggedInUser) return;

    const response = await fetch(`/friends/list/${encodeURIComponent(loggedInUser)}`);
    const friends = await response.json();

    friendsListContainer.innerHTML = "";

    if (friends.length === 0) {
        friendsListContainer.innerHTML = `<p class="empty-state">No friends yet</p>`;
        return;
    }

    friends.forEach((friend) => {
        const friendElement = document.createElement("div");
        friendElement.classList.add("friend-item");

        if (friend === selectedFriend) {
            friendElement.classList.add("active");
        }

        friendElement.textContent = friend;
        friendElement.addEventListener("click", () => {
            selectedFriend = friend;
            chatTitle.textContent = friend;
            chatSubtitle.textContent = `Direct messages with ${friend}`;
            contentInput.disabled = false;
            sendBtn.disabled = false;
            loadFriends();
            loadMessages();
        });

        friendsListContainer.appendChild(friendElement);
    });
}

function connectWebSocket(username) {
    if (socket) {
        socket.close();
    }

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    socket = new WebSocket(`${protocol}//${window.location.host}/chat`);

    socket.onopen = () => {
        socket.send(JSON.stringify({
            type: "register",
            username: username
        }));
    };

    socket.onmessage = (event) => {
        const message = JSON.parse(event.data);

        const isCurrentConversation =
            selectedFriend &&
            (
                (message.senderUsername === loggedInUser && message.receiverUsername === selectedFriend) ||
                (message.senderUsername === selectedFriend && message.receiverUsername === loggedInUser)
            );

        if (isCurrentConversation) {
            loadMessages();
        }
    };

    socket.onclose = () => {
        socket = null;
    };
}

function showChat(username) {
    loggedInUser = username;
    currentUser.textContent = username;
    authScreen.style.display = "none";
    chatScreen.style.display = "flex";
    connectWebSocket(username);
    loadFriendRequests();
    loadFriends();
    loadMessages();
}

function openLogoutModal() {
    logoutModal.classList.remove("hidden");
}

function closeLogoutModal() {
    logoutModal.classList.add("hidden");
}

function logout() {
    if (socket) {
        socket.close();
        socket = null;
    }

    loggedInUser = null;
    selectedFriend = null;

    authUsername.value = "";
    authPassword.value = "";
    authMessage.textContent = "";
    friendMessage.textContent = "";
    contentInput.value = "";
    friendUsernameInput.value = "";

    chatTitle.textContent = "Select a friend";
    chatSubtitle.textContent = "Choose someone from your friends list to start chatting";
    currentUser.textContent = "";
    messagesContainer.innerHTML = "";
    friendRequestsContainer.innerHTML = "";
    friendsListContainer.innerHTML = "";

    contentInput.disabled = true;
    sendBtn.disabled = true;

    closeLogoutModal();
    chatScreen.style.display = "none";
    authScreen.style.display = "flex";
}

async function signup() {
    const username = authUsername.value.trim();
    const password = authPassword.value.trim();

    if (!username || !password) {
        authMessage.textContent = "Enter username and password";
        return;
    }

    const response = await fetch("/auth/signup", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, password })
    });

    const result = await response.json();
    authMessage.textContent = result.message;

    if (result.success) {
        showChat(result.username);
    }
}

async function login() {
    const username = authUsername.value.trim();
    const password = authPassword.value.trim();

    if (!username || !password) {
        authMessage.textContent = "Enter username and password";
        return;
    }

    const response = await fetch("/auth/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, password })
    });

    const result = await response.json();
    authMessage.textContent = result.message;

    if (result.success) {
        showChat(result.username);
    }
}

async function sendFriendRequest() {
    const receiverUsername = friendUsernameInput.value.trim();

    if (!receiverUsername || !loggedInUser) {
        friendMessage.textContent = "Enter a username";
        return;
    }

    const response = await fetch("/friends/request", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            senderUsername: loggedInUser,
            receiverUsername: receiverUsername
        })
    });

    const result = await response.json();
    friendMessage.textContent = result.message;
    friendUsernameInput.value = "";
}

async function acceptFriendRequest(id) {
    const response = await fetch(`/friends/accept/${id}`, {
        method: "POST"
    });

    const result = await response.json();
    friendMessage.textContent = result.message;
    loadFriendRequests();
    loadFriends();
}

messageForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const content = contentInput.value.trim();

    if (!content || !loggedInUser || !selectedFriend) return;

    await fetch("/messages", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            senderUsername: loggedInUser,
            receiverUsername: selectedFriend,
            content: content
        })
    });

    contentInput.value = "";
    loadMessages();
});

signupBtn.addEventListener("click", signup);
loginBtn.addEventListener("click", login);
sendFriendRequestBtn.addEventListener("click", sendFriendRequest);
logoutBtn.addEventListener("click", openLogoutModal);
cancelLogoutBtn.addEventListener("click", closeLogoutModal);
confirmLogoutBtn.addEventListener("click", logout);

settingsBtn.addEventListener("click", () => {
    friendMessage.textContent = "Settings coming soon";
});

logoutModal.addEventListener("click", (event) => {
    if (event.target === logoutModal) {
        closeLogoutModal();
    }
});

setInterval(() => {
    if (loggedInUser) {
        loadFriendRequests();
        loadFriends();
        if (selectedFriend) {
            loadMessages();
        }
    }
}, 2000);

window.acceptFriendRequest = acceptFriendRequest;
